/**
 * 
 */
package com.notification;

/**
 * @author nsanda
 *
 */
public interface NotificationService {

	
}
