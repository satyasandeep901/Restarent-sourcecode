package com.food;

//import org.junit.Test;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageFoodServiceApplicationTests {

	
	@Test
	void contextLoads() {
	}
	
	
	

}
