package com.food.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FoodTestingContext {

	
}
