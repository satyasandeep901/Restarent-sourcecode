package com.authn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAuthnServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
