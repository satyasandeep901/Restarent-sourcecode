package com.authn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserAuthnServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserAuthnServiceApplication.class, args);
	}

}
