/**
 * 
 */
package com.authn.utils;

/**
 * @author nsanda
 *
 */
public interface AuthnConstants {

	String IDP_AUTHN_TYPE="IDPLogin";
	String DB_AUTHN_TYPE="DBLogin";
}
