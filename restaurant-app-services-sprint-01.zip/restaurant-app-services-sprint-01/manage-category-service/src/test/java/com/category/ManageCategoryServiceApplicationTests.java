package com.category;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageCategoryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
