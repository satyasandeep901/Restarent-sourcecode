package com.category;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManageCategoryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManageCategoryServiceApplication.class, args);
	}

}
